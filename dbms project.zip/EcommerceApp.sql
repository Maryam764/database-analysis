CREATE DATABASE EcommerceApp;
GO
USE EcommerceApp;
-- create tables here



CREATE TABLE Person (
    PersonID INT PRIMARY KEY,
    Name VARCHAR(100),
    Age INT,
    Gender VARCHAR(10),
    Contact VARCHAR(15)
);
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(30)
);
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    CategoryID INT,
    Price DECIMAL(10,2),
    Stock INT,
    ManufactureDate DATE,
    WarrantyExpiry DATE,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    PersonID INT,
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);
CREATE TABLE Roles (
    RoleID INT PRIMARY KEY,
    RoleName VARCHAR(15),
    RoleDescription VARCHAR(50)
);
CREATE TABLE Staff (
    StaffID INT PRIMARY KEY,
    RoleID INT,
    PersonID INT,
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID),
    FOREIGN KEY (PersonID) REFERENCES Person(PersonID)
);
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT,
    CustomerID INT,
    StaffID INT,
    Quantity INT,
    SaleDate DATE,
    TotalAmount DECIMAL(10,2),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID)
);
CREATE TABLE Invoice (
    InvoiceID INT PRIMARY KEY,
    SaleID INT,
    InvoiceDate DATE,
    PaymentMethod VARCHAR(20),
    FOREIGN KEY (SaleID) REFERENCES Sales(SaleID)
);

CREATE OR ALTER PROCEDURE AddPerson
    @PersonID INT,
    @Name VARCHAR(100),
    @Age INT,
    @Gender VARCHAR(10),
    @Contact VARCHAR(15)
AS
BEGIN
    INSERT INTO Person VALUES (@PersonID, @Name, @Age, @Gender, @Contact);
END;
GO

CREATE OR ALTER PROCEDURE AddCategory
    @CategoryID INT,
    @CategoryName VARCHAR(30)
AS
BEGIN
    INSERT INTO Category VALUES (@CategoryID, @CategoryName);
END;
GO

CREATE OR ALTER PROCEDURE AddProduct
    @ProductID INT,
    @ProductName VARCHAR(50),
    @CategoryID INT,
    @Price DECIMAL(10,2),
    @Stock INT,
    @ManufactureDate DATE,
    @WarrantyExpiry DATE
AS
BEGIN
    INSERT INTO Products VALUES (@ProductID, @ProductName, @CategoryID, @Price, @Stock, @ManufactureDate, @WarrantyExpiry);
END;
GO

CREATE OR ALTER PROCEDURE AddCustomer
    @CustomerID INT,
    @PersonID INT
AS
BEGIN
    INSERT INTO Customers VALUES (@CustomerID, @PersonID);
END;
GO

CREATE OR ALTER PROCEDURE AddRole
    @RoleID INT,
    @RoleName VARCHAR(15),
    @RoleDescription VARCHAR(50)
AS
BEGIN
    INSERT INTO Roles VALUES (@RoleID, @RoleName, @RoleDescription);
END;
GO

CREATE OR ALTER PROCEDURE AddStaff
    @StaffID INT,
    @RoleID INT,
    @PersonID INT
AS
BEGIN
    INSERT INTO Staff VALUES (@StaffID, @RoleID, @PersonID);
END;
GO

CREATE OR ALTER PROCEDURE AddSale
    @SaleID INT,
    @ProductID INT,
    @CustomerID INT,
    @StaffID INT,
    @Quantity INT,
    @SaleDate DATE,
    @TotalAmount DECIMAL(10,2)
AS
BEGIN
    INSERT INTO Sales VALUES (@SaleID, @ProductID, @CustomerID, @StaffID, @Quantity, @SaleDate, @TotalAmount);
END;
GO

CREATE OR ALTER PROCEDURE AddInvoice
    @InvoiceID INT,
    @SaleID INT,
    @InvoiceDate DATE,
    @PaymentMethod VARCHAR(20)
AS
BEGIN
    INSERT INTO Invoice VALUES (@InvoiceID, @SaleID, @InvoiceDate, @PaymentMethod);
END;
GO

CREATE OR ALTER PROCEDURE UpdatePersonContact
    @PersonID INT,
    @NewContact VARCHAR(15)
AS
BEGIN
    UPDATE Person SET Contact = @NewContact WHERE PersonID = @PersonID;
END;
GO



SELECT * FROM Person;
SELECT * FROM Category;
SELECT * FROM Products;
SELECT * FROM Customers;
SELECT * FROM Roles;
SELECT * FROM Staff;
SELECT * FROM Sales;
SELECT * FROM Invoice;

/* DELETE FROM Invoice;
DELETE FROM Sales;
DELETE FROM Staff;
DELETE FROM Roles;
DELETE FROM Customers;
DELETE FROM Products;
DELETE FROM Category;
DELETE FROM Person;

DROP TABLE Invoice;
DROP TABLE Sales;
DROP TABLE Staff;
DROP TABLE Roles;
DROP TABLE Customers;
DROP TABLE Products;
DROP TABLE Category;
DROP TABLE Person;


DROP TABLE IF EXISTS Invoice;
DROP TABLE IF EXISTS Sales;
DROP TABLE IF EXISTS Staff;
DROP TABLE IF EXISTS Roles;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS Person; */

