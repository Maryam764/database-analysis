const express = require('express');
const path = require('path');
const sql = require('mssql');

const server = express();
const PORT = 3000;

/* ---------- MIDDLEWARE ---------- */
server.use(express.json());
server.use(express.urlencoded({ extended: true }));

/* ---------- SERVE STATIC FILES ---------- */
server.use(express.static(__dirname));

/* ---------- SQL SERVER CONFIG (SQL AUTH) ---------- */
const dbConfig = {
    user: 'sales_user',
    password: 'sales123',
    server: 'DESKTOP-O32OKIB\\SQLEXPRESS',
    database: 'EcommerceApp',
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};

let pool;

/* ---------- CONNECT TO DATABASE ---------- */
sql.connect(dbConfig)
    .then(p => {
        pool = p;
        console.log("✅ Connected to SQL Server (EcommerceApp)");
    })
    .catch(err => {
        console.error("❌ Database connection failed:", err);
    });

/* ---------- LOAD HOME PAGE ---------- */
server.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

/* ---------- READ DATA FROM TABLE ---------- */
server.get('/api/:table', async (req, res) => {
    try {
        const table = req.params.table;
        const result = await pool.request().query(`SELECT * FROM ${table}`);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/* ---------- INSERT DATA INTO TABLE ---------- */
server.post('/api/:table', async (req, res) => {
    try {
        const table = req.params.table;
        const data = req.body;

        const columns = Object.keys(data).join(', ');
        const values = Object.values(data).map(v => `'${v}'`).join(', ');

        const query = `INSERT INTO ${table} (${columns}) VALUES (${values})`;
        await pool.request().query(query);

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/* ---------- START SERVER ---------- */
server.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
});
